---
name: switch
description: "Moom switch: Switch projects without mixing their state. Use for this workspace's switch procedure."
---

<!-- moom:generated; edit docs/commands or the job procedure, then sync -->
Read AGENTS.md and docs/process.md. Read current project state with python3 moom.py status --json.
Read docs/commands/switch.md in full and follow it.
Use plain-language requests equivalently; existing authorization and latest user instructions apply.
