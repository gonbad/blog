---
description: "Moom review-round: Open the next numbered review round. Use for this workspace's review-round procedure."
---

<!-- moom:generated; edit docs/commands or the job procedure, then sync -->
Read AGENTS.md and docs/process.md. Read current project state with python3 moom.py status --json.
Read docs/commands/review-round.md in full and follow it.
Use plain-language requests equivalently; existing authorization and latest user instructions apply.
