# What counts as a good result?

During /job, write concrete human judgment criteria and useful mechanical checks for the selected task. Keep a representative example and corrections that actually generalize. Completion does not require a measured speed improvement.
