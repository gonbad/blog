# Moom

Read AGENTS.md, docs/profile.md, docs/process.md and docs/status.md.
Commands in .claude/commands route to canonical docs/commands procedures.
For job milestones, resolve the selected project's pinned instructions with `python3 moom.py procedure STEP`.
Ordinary language requests follow the same procedures. Existing user authorization remains valid.
