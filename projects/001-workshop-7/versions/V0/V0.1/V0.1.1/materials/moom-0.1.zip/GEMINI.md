# Moom

Read AGENTS.md, docs/profile.md, docs/process.md and docs/status.md.
Generated skills in .agents/skills and the .agents/rules/moom.md rule route to canonical procedures.
Resolve job milestones for the selected project with `python3 moom.py procedure STEP`.
Use the user's languages and authorization; present concise decision reviews.
