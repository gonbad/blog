#!/usr/bin/env python3
"""Moom workspace mechanics. Python standard library only; procedures are Markdown."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile

KIT_VERSION = "0.1"
KIT = Path(__file__).resolve().parent


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    pending = path.with_suffix(path.suffix + ".next")
    pending.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    pending.replace(path)


def within(root, name):
    path = (root / name).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError(f"Path leaves workspace: {name}")
    return path


def digest(path):
    if path.is_file():
        return hashlib.sha256(path.read_bytes()).hexdigest()
    if not path.is_dir():
        raise ValueError(f"Missing artifact: {path}")
    entries = [(p.relative_to(path).as_posix(), digest(p)) for p in sorted(path.rglob("*")) if p.is_file()]
    return hashlib.sha256(json.dumps(entries).encode()).hexdigest()


def workspace(root):
    return read(root / "docs/workspace.json")


def project(root, config, identifier=None):
    identifier = identifier or config.get("active_project")
    if identifier not in config["projects"]:
        raise ValueError("Select a registered project with switch, or create one with new")
    return read(within(root, config["projects"][identifier]))


def save_project(root, config, state):
    write(within(root, config["projects"][state["id"]]), state)


def version_number(value):
    value = value.removeprefix("V").removeprefix("v")
    if not re.fullmatch(r"\d+(?:\.\d+){1,2}", value):
        raise ValueError("Use a numeric project version, such as V0.2 or 0.2")
    return value


def project_docs(root, state):
    return within(root, state.get("docs", f"docs/projects/{state['id']}"))


def relative_link(path, folder):
    return Path(os.path.relpath(path, folder)).as_posix()


def rebase_markdown(text, old_folder, new_folder, old_tree=None, new_tree=None, retained=()):
    def link(match):
        target = match.group(2)
        if not target or target.startswith(("/", "#")) or re.match(r"[a-z]+:", target):
            return match.group(0)
        name, marker, fragment = target.partition("#")
        resolved = (old_folder / name).resolve()
        if old_tree and resolved.is_relative_to(old_tree):
            relative = resolved.relative_to(old_tree)
            if relative.parts and not any(Path(relative.parts[0]).match(pattern) for pattern in retained):
                resolved = new_tree / relative
        return match.group(1) + relative_link(resolved, new_folder) + (marker + fragment if marker else "") + ")"
    return re.sub(r"(!?\[[^\]]*\]\()([^\s)]+)\)", link, text)


def initialize_version(root, state):
    """Adopt legacy documents once, preserving answers and stable old links."""
    docs = root / "docs/projects" / state["id"]
    version = version_number(state["version"])
    destination = docs / "versions" / ("V" + version)
    if not state.get("docs"):
        destination.mkdir(parents=True, exist_ok=True)
        moved = [p for p in docs.iterdir() if p.name not in ("state.json", "versions", "issues", "roadmap.md", "README.md")]
        for source in moved:
            target = destination / source.name
            if target.exists(): raise ValueError(f"Version document already exists: {target}")
        for source in moved:
            target = destination / source.name
            shutil.move(str(source), target)
            for item in [target] if target.is_file() else target.rglob("*"):
                if item.suffix == ".md":
                    old = docs / item.relative_to(destination)
                    item.write_text(rebase_markdown(item.read_text(encoding="utf-8"), old.parent, item.parent, docs, destination, retained=("state.json", "issues", "versions", "roadmap.md", "README.md")), encoding="utf-8")
            if source.suffix == ".md":
                source.write_text(f"# Versioned document\n\nCurrent location: [{source.name}]({relative_link(target, docs)}).\n", encoding="utf-8")
        state["docs"] = destination.relative_to(root).as_posix()
        for record in state.get("milestones", {}).values():
            original = within(root, record["artifact"])
            for source in moved:
                if original == source or original.is_relative_to(source):
                    target = destination / original.relative_to(docs)
                    record["artifact"] = target.relative_to(root).as_posix()
                    # Rebasing a link changes bytes; acceptance must not be invented.
                    if record["state"] == "accepted" and digest(target) != record["sha256"]:
                        record["state"] = "stale"
                    elif record["state"] != "accepted": record["sha256"] = digest(target)
        review = state.get("pending_review", {})
        if review.get("file"):
            original = within(root, review["file"])
            if original.parent == docs:
                review["file"] = (destination / original.name).relative_to(root).as_posix()
    destination = project_docs(root, state)
    if not (destination / "version.json").exists():
        write(destination / "version.json", {"version": version, "status": "working", "workflow_at_start": state["workflow"], "source": f"projects/{state['id']}/", "created_at": now()})
    physical = root / "projects" / state["id"]
    if not (physical / "roadmap.md").exists():
        (physical / "roadmap.md").write_text(f"# {state['title']} — roadmap\n\nSee [versions](README.md).\n\n## Current scope\n\nCapture the requested result and remaining review/work here.\n\n## Later candidates\n\nUnscheduled; a roadmap item does not authorize a version change or publication.\n", encoding="utf-8")
    refresh_version_index(root, state)
    return destination


def refresh_version_index(root, state):
    physical = root / "projects" / state["id"]
    docs = root / "docs/projects" / state["id"]
    lines = [f"# {state['id']} — {state['title']}", "", f"Working version: **V{state['version']}**. Workflow revision is independent.", "", "[Project roadmap](roadmap.md)", "", "| Version | Documents | Source |", "| --- | --- | --- |"]
    for folder in sorted((docs / "versions").glob("V*")):
        active = folder.name == "V" + state["version"]
        source = physical if active else physical / "versions" / folder.name
        lines.append(f"| {folder.name}{' (working)' if active else ''} | [docs]({relative_link(folder, physical)}/) | [source]({relative_link(source, physical)}/) |")
    lines += ["", "The working source is edited in this project folder. Starting a new version snapshots the previous source under versions/V…/ and preserves its documents. Publication receipts are stored with the version's documents. Historical pre-migration versions are available through Git; they are not reconstructed as invented snapshots."]
    (physical / "README.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    roadmap = physical / "roadmap.md"
    if roadmap.exists():
        text = roadmap.read_text(encoding="utf-8")
        block = f"<!-- moom:current-version -->\nWorking version: **V{state['version']}** · [version documents]({relative_link(project_docs(root, state), physical)}/)\n<!-- /moom:current-version -->"
        pattern = r"<!-- moom:current-version -->.*?<!-- /moom:current-version -->"
        text = re.sub(pattern, lambda _: block, text, flags=re.S) if re.search(pattern, text, flags=re.S) else text.rstrip() + "\n\n" + block + "\n"
        roadmap.write_text(text, encoding="utf-8")


def change_entry(root, destination, args, marker):
    """Two entry routes: create 01-request.md, or adopt the owner's 01-*.md."""
    requested = getattr(args, "input", None)
    if (destination / marker).exists():
        raise ValueError("Version already initialized; refusing to overwrite history")
    if requested:
        source = within(root, requested)
        if source.parent != destination or not re.fullmatch(r"01-[a-zA-Z0-9_-]+\.md", source.name) or not source.is_file():
            raise ValueError("--input must name the primary 01-*.md file in the target version directory")
        primaries = list(destination.glob("01-*.md"))
        if len(primaries) != 1:
            raise ValueError("Select exactly one primary 01-*.md change input per version")
        return {"file": source.name, "entry_mode": "owner-prepared", "sha256": digest(source)}, None
    if destination.exists():
        raise ValueError("Prepared version folder exists; adopt its primary file with --input instead of replacing it")
    content = f"# Requested version change\n\n{getattr(args, 'note', None) or 'Freeze the current discovered working method as this revision.'}\n"
    return {"file": "01-request.md", "entry_mode": "agent-assisted", "sha256": hashlib.sha256(content.encode()).hexdigest()}, content


def merge_prepared(staged, destination):
    """Publish derived files without replacing anything the owner supplied."""
    destination.mkdir(parents=True, exist_ok=True)
    for item in sorted(staged.rglob("*")):
        relative = item.relative_to(staged)
        target = within(destination, relative)
        if item.is_dir(): target.mkdir(parents=True, exist_ok=True)
        elif not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, target)


def iterate_project(root, config, state, args):
    version = version_number(args.version)
    order = lambda v: tuple(map(int, version_number(v).split("."))) + (0,) * (3 - len(version_number(v).split(".")))
    if order(version) <= order(state["version"]): raise ValueError("A new version must be greater than the current version")
    physical = root / "projects" / state["id"]
    new_docs = root / "docs/projects" / state["id"] / "versions" / ("V" + version)
    snapshot = physical / "versions" / ("V" + state["version"])
    if snapshot.exists(): raise ValueError("Version already exists; refusing to overwrite history")
    entry, request_text = change_entry(root, new_docs, args, "version.json")
    docs = initialize_version(root, state)
    with tempfile.TemporaryDirectory(prefix="moom-version-", dir=root) as temporary:
        staged = Path(temporary) / "source"
        staged.mkdir()
        for item in physical.iterdir():
            if item.name in ("versions", ".git", "node_modules", "dist", "__pycache__") or item.name.startswith(".env"): continue
            target = staged / item.name
            if item.is_dir(): shutil.copytree(item, target, ignore=shutil.ignore_patterns(".git", "node_modules", "__pycache__", ".env", ".env.*"))
            else: shutil.copy2(item, target)
        manifest = {p.relative_to(staged).as_posix(): digest(p) for p in sorted(staged.rglob("*")) if p.is_file()}
        write(staged / "snapshot.json", {"version": state["version"], "workflow": state["workflow"], "at": now(), "sha256": manifest})
        shutil.copytree(docs, Path(temporary) / "docs")
        copied_docs = Path(temporary) / "docs"
        for item in copied_docs.rglob("*.md"):
            old = docs / item.relative_to(copied_docs)
            new = new_docs / item.relative_to(copied_docs)
            item.write_text(rebase_markdown(item.read_text(encoding="utf-8"), old.parent, new.parent, docs, new_docs, retained=("[0-9]*-review.md", "01-*.md", "releases", "version.json", "state-at-close.json")), encoding="utf-8")
        # Review answers and release evidence belong only to the old version.
        for pattern in ("[0-9]*-review.md", "01-*.md", "version.json", "state-at-close.json", "releases"):
            for item in copied_docs.glob(pattern):
                if item.is_dir(): shutil.rmtree(item)
                else: item.unlink()
        if new_docs.exists(): shutil.copytree(new_docs, copied_docs, dirs_exist_ok=True)
        if request_text is not None: (copied_docs / entry["file"]).write_text(request_text, encoding="utf-8")
        write(copied_docs / "version.json", {"version": version, "previous": state["version"], "status": "working", "workflow_at_start": state["workflow"], "change": args.note, "change_input": entry, "created_at": now()})
        (copied_docs / "changes.md").write_text(f"# V{version}\n\n{args.note}\n\nInherited specifications are a baseline, not approval of this version. Review new questions and uncertain decisions in a new numbered review round.\n", encoding="utf-8")
        if request_text is None and digest(new_docs / entry["file"]) != entry["sha256"]:
            raise ValueError("Primary input changed during adoption; reread the current file before continuing")
        snapshot.parent.mkdir(exist_ok=True)
        shutil.move(staged, snapshot)
        merge_prepared(copied_docs, new_docs)
    write(docs / "state-at-close.json", state)
    value = read(docs / "version.json"); value["status"] = "archived"; value["snapshot"] = snapshot.relative_to(root).as_posix(); write(docs / "version.json", value)
    state.setdefault("releases", []).append({"version": state["version"], "next_version": version, "note": args.note, "snapshot": snapshot.relative_to(root).as_posix(), "at": now()})
    state["version"] = version; state["docs"] = new_docs.relative_to(root).as_posix(); state["milestones"] = {}
    state.pop("pending_review", None); state.pop("review_history", None)
    metadata = read(physical / "project.json")
    if metadata.get("publish"):
        metadata["published_snapshot"] = snapshot.relative_to(physical).as_posix()
    if metadata.get("kind") in ("post", "index"): metadata["publish"] = False
    metadata["version"] = version
    if metadata.get("archive"): metadata["archive"] = f"{state['id']}-v{version}.zip"
    metadata.pop("archive_aliases", None)
    write(physical / "project.json", metadata); save_project(root, config, state)
    refresh_version_index(root, state)
    return {"project": state["id"], "version": version, "docs": state["docs"], "change_input": entry, "previous_source": snapshot.relative_to(root).as_posix(), "publication": "unchanged; new version is a draft"}


def review_round(root, config, state, args):
    if state.get("pending_review", {}).get("state") == "waiting":
        raise ValueError("Read and record the existing round's answers before opening another round")
    flow, _ = recipe(root, config, state)
    if args.before not in {s["id"] for s in flow["steps"]}: raise ValueError("Unknown review milestone")
    docs = initialize_version(root, state)
    number = max([int(p.name.split("-", 1)[0]) for p in docs.glob("[0-9]*-review.md")] + [0]) + 1
    path = docs / f"{number:03d}-review.md"
    path.write_text(f"# Round {number:03d} — {args.title}\n\nProject: {state['id']} · V{state['version']} · workflow {flow['revision']}\nStatus: awaiting file submission. On submission, blank fields follow the owner's review policy; delegated choices are local defaults, not hard rules or explicit acceptance.\n\n## Questions — choose an option\n\n### Q1 — Replace with an unresolved question\n\n- A. Recommended choice **(Recommended)** — explain the tradeoff.\n- B. Alternative — explain the tradeoff.\n\nAnswer:\n\n## Uncertain decisions — confirm or override\n\n### D1 — Replace with one proposed decision\n\nProposed decision: state the decision and why it is uncertain.\n\nConfirmation / override:\n\n## Additional comments\n\n", encoding="utf-8")
    review = {"round": number, "state": "waiting", "file": path.relative_to(root).as_posix(), "before": args.before, "created_at": now()}
    state["pending_review"] = review; state.setdefault("review_history", []).append(dict(review)); save_project(root, config, state)
    return review


def recipe(root, config, state=None):
    name = state.get("workflow") if state else None
    name = name or config["workflow"]
    path = within(root, name)
    return read(path), path.parent


def validate_recipe(root, value, folder):
    if not isinstance(value.get("steps"), list):
        raise ValueError("Workflow needs an ordered steps list")
    seen = set()
    for step in value["steps"]:
        identifier = step["id"]
        if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", identifier) or identifier in seen:
            raise ValueError(f"Invalid/duplicate milestone ID: {identifier}")
        if not set(step.get("depends_on", [])) <= seen:
            raise ValueError(f"Dependencies must refer to earlier milestones: {identifier}")
        if not within(folder, step["procedure"]).is_file():
            raise ValueError(f"Missing procedure for {identifier}")
        if not set(step.get("helpers", [])) <= set(value.get("helpers", {})):
            raise ValueError(f"Unknown helper for {identifier}")
        if not set(step.get("resources", [])) <= set(value.get("resources", [])):
            raise ValueError(f"Unknown reusable resource for {identifier}")
        seen.add(identifier)
    for helper in value.get("helpers", {}).values():
        if not within(root if not helper.get("bundled") else folder, helper["path"]).is_file():
            raise ValueError(f"Missing helper: {helper['path']}")
        if not isinstance(helper.get("command"), list) or "{helper}" not in helper["command"]:
            raise ValueError("Helper command must be an argument list containing {helper}")
        if not set(helper.get("resources", [])) <= set(value.get("resources", [])):
            raise ValueError("A helper references an undeclared reusable resource")
    for name in value.get("resources", []):
        if not within(folder / "bundle" if value.get("resources_bundled") else root, name).is_file():
            raise ValueError(f"Missing reusable helper resource: {name}")


def render(root):
    config = workspace(root)
    lines = ["# Workspace status", "", f"Moom kit: {config['kit_version']}", f"Projects: {len(config['projects'])}"]
    if config.get("active_project"):
        state = project(root, config)
        flow, _ = recipe(root, config, state)
        steps = flow["steps"]
        pending = next((s for s in steps if state["milestones"].get(s["id"], {}).get("state") not in ("ready", "accepted")), None)
        review = state.get("pending_review", {})
        waiting = review.get("state") == "waiting"
        next_action = f"await saved answers in {review['file']}" if waiting else pending['id'] if pending else 'ready for owner feedback / next project'
        tokens = []
        for step in steps:
            status = state["milestones"].get(step["id"], {}).get("state", "pending")
            mark = "✅" if status == "accepted" else "◉" if status == "ready" else "⚠️" if status == "stale" else "➡️" if pending and pending["id"] == step["id"] else "⬜"
            tokens.append(f"{mark} {step['id']}")
        lines += [f"Active project: **{state['id']}** — {state['title']}", f"Project version: {state['version']}",
                  f"Workflow: {flow['revision']} ({flow.get('status', 'draft')})", f"Source: `projects/{state['id']}/`",
                  f"Artifacts ready: {sum(state['milestones'].get(s['id'], {}).get('state') in ('ready', 'accepted') for s in steps)}/{len(steps)} · Human accepted: {sum(state['milestones'].get(s['id'], {}).get('state') == 'accepted' for s in steps)}/{len(steps)}",
                  f"Next: {next_action}", "", " · ".join(tokens), "",
                  f"Documents: [{state['version']}]({relative_link(project_docs(root, state), root / 'docs')}/)",
                  f"Roadmap: [roadmap.md](../projects/{state['id']}/roadmap.md)",
                  f"State: [state.json](projects/{state['id']}/state.json)",
                  f"Workflow: [workflow.json]({state.get('workflow', config['workflow']).removeprefix('docs/')})"]
    else:
        lines += ["Active project: none", "Next: /start, then /job with the first real example."]
    lines += ["", "Generated from workspace/project state. Approval is recorded separately from artifact readiness."]
    (root / "docs/status.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return "\n".join(lines)


def install(root):
    if root != KIT and (workspace(KIT)["projects"] or recipe(KIT, workspace(KIT))[0].get("id")):
        raise ValueError("Use export/import to reuse a configured job; init installs the clean workshop kit")
    root.mkdir(parents=True, exist_ok=True)
    names = ["AGENTS.md", "CLAUDE.md", "GEMINI.md", "README.md", "workflow.md", "roadmap.md", ".gitignore", "moom.py", "docs/profile.md", "docs/process.md", "docs/workspace.json"]
    names += [p.relative_to(KIT).as_posix() for p in (KIT / "docs/commands").glob("*.md")]
    names += [p.relative_to(KIT).as_posix() for p in (KIT / "docs/job").glob("*") if p.is_file()]
    for name in names:
        source, target = KIT / name, root / name
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
    config = workspace(root)
    config["kit_version"] = KIT_VERSION
    write(root / "docs/workspace.json", config)
    render(root)
    return {"workspace": str(root), "kit_version": KIT_VERSION, "preserved_existing_files": True}


def new_project(root, args):
    config = workspace(root)
    args.version = version_number(args.version)
    if args.first:
        existing = next((p for p in config["projects"] if p.startswith("001-")), None)
        if existing:
            config["active_project"] = existing
            write(root / "docs/workspace.json", config)
            return {"project": existing, "resumed": True}
    selected_workflow = config.get("approved_workflow") or config.get("latest_workflow") or config["workflow"]
    flow = read(within(root, selected_workflow))
    slug = args.slug
    if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", slug):
        raise ValueError("Use a lowercase ASCII slug; keep the human title in --title")
    if args.adopt:
        identifier = slug
        if not re.fullmatch(r"\d{3,}-[a-z0-9-]+", identifier):
            raise ValueError("Adopt requires the full numbered project ID")
    else:
        numbers = [int(p.split("-", 1)[0]) for p in config["projects"]]
        numbers += [int(p.name.split("-", 1)[0]) for p in (root / "projects").glob("[0-9]*-*") if p.name.split("-", 1)[0].isdigit()]
        identifier = f"{max(numbers + [0]) + 1:03d}-{slug}"
    if identifier in config["projects"]:
        raise ValueError(f"Project already registered: {identifier}")
    physical = root / "projects" / identifier
    if physical.exists() and not args.adopt:
        raise ValueError(f"Project directory already exists: {identifier}")
    layout = flow.get("project_layout", {"source": "src", "kind": "artifact"})
    for part in ("inputs", layout["source"]):
        (physical / part).mkdir(parents=True, exist_ok=True)
    metadata = physical / "project.json"
    if not metadata.exists():
        write(metadata, {"id": identifier, "title": args.title or slug, "kind": layout["kind"], "source": layout["source"], "version": args.version, **layout.get("metadata", {})})
    docs = root / "docs/projects" / identifier
    docs.mkdir(parents=True, exist_ok=True)
    brief = docs / "brief.md"
    if not brief.exists():
        brief.write_text(f"# {args.title or slug}\n\nRecord this instance's inputs, desired result, and unresolved decisions here.\n", encoding="utf-8")
    state = {"id": identifier, "title": args.title or slug, "version": args.version,
             "workflow": selected_workflow, "created_at": now(), "milestones": {}, "issues": []}
    state["version"] = version_number(state["version"])
    initialize_version(root, state)
    config["projects"][identifier] = f"docs/projects/{identifier}/state.json"
    config["active_project"] = identifier
    write(docs / "state.json", state)
    write(root / "docs/workspace.json", config)
    return {"project": identifier, "workflow": state["workflow"], "source": str(physical)}


def freeze(root, args):
    if not re.fullmatch(r"\d+(?:\.\d+){1,2}", args.revision):
        raise ValueError("Use a numeric workflow revision, such as 0.1")
    config = workspace(root)
    value, folder = recipe(root, config)
    if not value.get("id") or not value["steps"]:
        raise ValueError("Discover the real job before freezing a method")
    validate_recipe(root, value, folder)
    final = root / "docs/job/versions" / args.revision
    entry, request_text = change_entry(root, final, args, "workflow.json")
    with tempfile.TemporaryDirectory(prefix="moom-method-", dir=root) as temporary:
        destination = Path(temporary) / "method"
        destination.mkdir()
        value["revision"] = args.revision
        value["status"] = "approved" if args.evidence else "candidate"
        value["review_reference"] = args.evidence
        value["change_input"] = entry
        for path in sorted(folder.rglob("*")):
            if path.is_file() and "versions" not in path.relative_to(folder).parts:
                if path.parent == folder and re.fullmatch(r"01-.*\.md", path.name): continue
                target = destination / path.relative_to(folder)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(path, target)
        for helper in value.get("helpers", {}).values():
            original = within(folder if helper.get("bundled") else root, helper["path"])
            source_path = helper.get("source_path", helper["path"])
            relative = "bundle/" + source_path
            target = destination / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(original, target)
            helper.update(path=relative, source_path=source_path, bundled=True, sha256=digest(target))
        resource_hashes = {}
        for name in value.get("resources", []):
            original = within(folder / "bundle" if value.get("resources_bundled") else root, name)
            target = within(destination / "bundle", name)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(original, target)
            resource_hashes[name] = digest(target)
        value["resources_bundled"] = True
        value["resource_sha256"] = resource_hashes
        if request_text is not None:
            (destination / entry["file"]).write_text(request_text, encoding="utf-8")
        elif digest(final / entry["file"]) != entry["sha256"]:
            raise ValueError("Primary method input changed during adoption; reread it")
        # Prepared notes/procedures belong to the owner. Bundled executable
        # resources must agree with the selected working method before freezing.
        for item in (destination / "bundle").rglob("*") if (destination / "bundle").exists() else []:
            target = final / item.relative_to(destination)
            if item.is_file() and target.exists() and digest(item) != digest(target):
                raise ValueError("Prepared helper/resource differs; integrate it into the working method before freeze")
        write(destination / "workflow.json", value)
        merge_prepared(destination, final)
    config["latest_workflow"] = f"docs/job/versions/{args.revision}/workflow.json"
    if args.evidence:
        config["approved_workflow"] = f"docs/job/versions/{args.revision}/workflow.json"
    write(root / "docs/workspace.json", config)
    return {"workflow": final.relative_to(root).as_posix() + "/workflow.json", "status": value["status"], "change_input": entry}


def step_signature(root, folder, flow, step):
    payload = dict(step)
    payload["procedure_digest"] = digest(within(folder, step["procedure"]))
    payload["helper_digests"] = {name: digest(within(folder if flow["helpers"][name].get("bundled") else root, flow["helpers"][name]["path"])) for name in step.get("helpers", [])}
    resources = set(step.get("resources", []))
    for name in step.get("helpers", []): resources.update(flow["helpers"][name].get("resources", []))
    payload["resource_digests"] = {name: digest(within(folder / "bundle" if flow.get("resources_bundled") else root, name)) for name in sorted(resources)}
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()


def migrate(root, args):
    config = workspace(root)
    state = project(root, config, args.project)
    old, old_folder = recipe(root, config, state)
    name = f"docs/job/versions/{args.revision}/workflow.json"
    new_folder = within(root, name).parent
    target = read(within(root, name))
    validate_recipe(root, target, new_folder)
    previous = {step["id"]: step for step in old["steps"]}
    affected = set()
    for step in target["steps"]:
        identifier = step["id"]
        if identifier not in previous or step_signature(root, old_folder, old, previous[identifier]) != step_signature(root, new_folder, target, step) or affected.intersection(step.get("depends_on", [])):
            affected.add(identifier)
            if identifier in state["milestones"]:
                state["milestones"][identifier]["state"] = "stale"
    state.setdefault("migrations", []).append({"from": state["workflow"], "to": name, "affected": sorted(affected), "note": args.note, "at": now()})
    state["workflow"] = name
    save_project(root, config, state)
    return {"project": state["id"], "workflow": name, "reopened": sorted(affected)}


def record_step(root, args):
    config = workspace(root)
    state = project(root, config)
    flow, _ = recipe(root, config, state)
    step = next((s for s in flow["steps"] if s["id"] == args.step), None)
    if not step:
        raise ValueError(f"Unknown milestone: {args.step}")
    if args.state == "accepted":
        if not args.evidence:
            raise ValueError("Acceptance requires the actual user approval reference")
        for dependency in step.get("depends_on", []):
            record = state["milestones"].get(dependency, {})
            if record.get("state") != "accepted" or not within(root, record["artifact"]).exists() or digest(within(root, record["artifact"])) != record["sha256"]:
                raise ValueError("Accept current dependency artifacts first, or explicitly revise the workflow")
    artifact = within(root, args.artifact)
    state["milestones"][args.step] = {"state": args.state, "artifact": artifact.relative_to(root).as_posix(), "sha256": digest(artifact), "evidence": args.evidence, "at": now()}
    save_project(root, config, state)
    return state["milestones"][args.step]


def issue(root, args):
    config = workspace(root)
    state = project(root, config)
    docs = root / "docs/projects" / state["id"] / "issues"
    docs.mkdir(parents=True, exist_ok=True)
    number = max([int(p.stem.split("-", 1)[0]) for p in docs.glob("[0-9]*.md")] + [0]) + 1
    path = docs / f"{number:03d}.md"
    path.write_text(f"# Issue {number:03d} — {args.title}\n\nScope: {args.scope}\nProject: {state['id']} · {state['version']}\n\n## Report\n{args.title}\n\n## Cause\nNot diagnosed yet.\n\n## Correction and verification\nPending investigation; record observed evidence here.\n\n## Reusable change\nDecide whether the project, helper, job workflow or Moom core also changes.\n", encoding="utf-8")
    state["issues"].append({"path": path.relative_to(root).as_posix(), "scope": args.scope, "state": "open", "title": args.title})
    save_project(root, config, state)
    return {"issue": path.relative_to(root).as_posix()}


def sync(root, check=False):
    config = workspace(root)
    definitions = {p.stem: (p.read_text(encoding="utf-8").splitlines()[0].lstrip("# "), f"Read docs/commands/{p.name} in full and follow it.") for p in (root / "docs/commands").glob("*.md")}
    core_commands = set(definitions)
    for state_path in config["projects"].values():
        state = read(within(root, state_path))
        flow, _ = recipe(root, config, state)
        for step in flow["steps"]:
            if step["id"] in core_commands:
                raise ValueError(f"Job milestone collides with a core command: {step['id']}")
            definitions[step["id"]] = (step["title"], f"Run python3 moom.py procedure {step['id']}; read the returned selected-project procedure and follow it.")
    if not config["projects"]:
        flow, _ = recipe(root, config)
        for step in flow["steps"]:
            definitions[step["id"]] = (step["title"], f"Run python3 moom.py procedure {step['id']} and follow the selected project's procedure.")
    manifest_path = root / ".moom-generated.json"
    owned = read(manifest_path) if manifest_path.exists() else {}
    outputs = {}
    for name, (description, instruction) in definitions.items():
        description = f"Moom {name}: {description}. Use for this workspace's {name} procedure."
        body = f"\n<!-- moom:generated; edit docs/commands or the job procedure, then sync -->\nRead AGENTS.md and docs/process.md. Read current project state with python3 moom.py status --json.\n{instruction}\nUse plain-language requests equivalently; existing authorization and latest user instructions apply.\n"
        for directory in (".claude/commands", ".opencode/commands"):
            outputs[f"{directory}/{name}.md"] = f"---\ndescription: {json.dumps(description)}\n---\n" + body
        outputs[f".agents/skills/{name}/SKILL.md"] = f"---\nname: {name}\ndescription: {json.dumps(description)}\n---\n" + body
    outputs[".agents/rules/moom.md"] = "Read AGENTS.md and docs/status.md. Procedures live in docs/commands. Job steps resolve through python3 moom.py procedure STEP for the selected project's workflow revision.\n"
    conflicts = []
    for name, text in outputs.items():
        path = root / name
        if path.exists() and path.read_text(encoding="utf-8") != text and owned.get(name) != digest(path):
            conflicts.append(name)
    obsolete = [name for name in owned if name not in outputs and (root / name).exists()]
    conflicts += [name for name in obsolete if digest(root / name) != owned[name]]
    if conflicts:
        raise ValueError("Generated files contain local edits; resolve before sync: " + ", ".join(conflicts))
    drift = [name for name, text in outputs.items() if not (root / name).is_file() or (root / name).read_text(encoding="utf-8") != text] + obsolete
    if check:
        if drift:
            raise ValueError("Run sync; generated-file drift: " + ", ".join(drift))
    else:
        for name in obsolete:
            (root / name).unlink()
        for name, text in outputs.items():
            path = root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(text, encoding="utf-8")
        write(manifest_path, {name: digest(root / name) for name in outputs})
    return {"commands": len(definitions), "files": len(outputs), "hosts": ["Claude Code", "OpenCode", "Codex", "Antigravity"], "check": check, "native_host_discovery": "not asserted by file checks"}


def export_job(root, args):
    config = workspace(root)
    state = project(root, config) if config.get("active_project") else None
    flow, folder = recipe(root, config, state)
    target = Path(args.output).resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="moom-export-") as temporary:
        staged = Path(temporary)
        for name in ("moom.py", "AGENTS.md", "CLAUDE.md", "GEMINI.md"):
            shutil.copy2(root / name, staged / name)
        shutil.copytree(root / "docs/commands", staged / "docs/commands")
        shutil.copy2(root / "docs/process.md", staged / "docs/process.md")
        if "versions" not in folder.parts:
            raise ValueError("Freeze the recipe before exporting its reusable kit")
        relative = Path("docs/job")
        shutil.copytree(folder, staged / relative)
        imported_flow = read(staged / relative / "workflow.json")
        imported_flow.pop("review_reference", None)
        imported_flow["status"] = "recipient_review_required"
        imported_flow["source_recipe_sha256"] = digest(folder / "workflow.json")
        write(staged / relative / "workflow.json", imported_flow)
        overview = ["# Imported reusable workflow", "", "Start with /start, then your own first input. The recipient reviews this method and its dependencies.", ""]
        overview += [f"- `{step['id']}` — [{step['title']}](docs/job/{step['procedure']})" for step in flow["steps"]]
        (staged / "workflow.md").write_text("\n".join(overview) + "\n", encoding="utf-8")
        fresh = {"schema": 1, "kit_version": KIT_VERSION, "workflow": (relative / "workflow.json").as_posix(), "active_project": None, "projects": {}, "import_review": "required"}
        write(staged / "docs/workspace.json", fresh)
        (staged / "docs/profile.md").write_text("# Recipient profile\n\nConfirm conversation/document languages and local tools in /start.\n", encoding="utf-8")
        (staged / "README.md").write_text("# Reusable Moom job kit\n\nOpen this folder in your assistant and request /start, then /job or /project with your own input. Read docs/process.md and the imported task definition. Review recipient setup and dependencies before using the method. No source project inputs are included.\n", encoding="utf-8")
        (staged / "roadmap.md").write_text("# Workspace roadmap\n\nReview the imported method, start your own first project, and capture future improvements here. Project roadmaps live in projects/ID/roadmap.md.\n", encoding="utf-8")
        render(staged)
        subprocess.run([sys.executable, str(staged / "moom.py"), "sync"], cwd=staged, check=True, capture_output=True)
        with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(staged.rglob("*")):
                if path.is_file(): archive.write(path, path.relative_to(staged).as_posix())
    return {"export": str(target), "project_inputs_included": False, "review": "required in receiving workspace"}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, default=KIT)
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("init")
    status = commands.add_parser("status"); status.add_argument("--json", action="store_true")
    create = commands.add_parser("new"); create.add_argument("slug"); create.add_argument("--title"); create.add_argument("--version", default="0.1"); create.add_argument("--first", action="store_true"); create.add_argument("--adopt", action="store_true")
    switch = commands.add_parser("switch"); switch.add_argument("project")
    freezing = commands.add_parser("freeze"); freezing.add_argument("revision"); freezing.add_argument("--evidence"); freezing.add_argument("--note"); freezing.add_argument("--input")
    migration = commands.add_parser("migrate"); migration.add_argument("revision"); migration.add_argument("--project"); migration.add_argument("--note", required=True)
    step = commands.add_parser("record"); step.add_argument("step"); step.add_argument("--state", choices=["ready", "accepted", "stale"], default="ready"); step.add_argument("--artifact", required=True); step.add_argument("--evidence")
    procedure = commands.add_parser("procedure"); procedure.add_argument("step")
    running = commands.add_parser("run"); running.add_argument("helper")
    report = commands.add_parser("issue"); report.add_argument("title"); report.add_argument("--scope", choices=["project", "helper", "workflow", "moom"], default="project")
    iterate = commands.add_parser("iterate"); iterate.add_argument("--version", required=True); iterate.add_argument("--note", required=True); iterate.add_argument("--input")
    commands.add_parser("versions")
    review = commands.add_parser("review-round"); review.add_argument("--title", required=True); review.add_argument("--before", required=True)
    synchronization = commands.add_parser("sync"); synchronization.add_argument("--check", action="store_true")
    commands.add_parser("check")
    exporting = commands.add_parser("export"); exporting.add_argument("--output", required=True)
    importing = commands.add_parser("import-job"); importing.add_argument("archive", type=Path)
    args = parser.parse_args(argv)
    root = args.workspace.resolve()
    if args.command == "init":
        result = install(root)
        result["integration"] = sync(root)
    elif args.command == "new": result = new_project(root, args)
    elif args.command == "sync": result = sync(root, args.check)
    elif args.command == "freeze": result = freeze(root, args)
    elif args.command == "migrate": result = migrate(root, args)
    elif args.command == "record": result = record_step(root, args)
    elif args.command == "issue": result = issue(root, args)
    elif args.command == "export": result = export_job(root, args)
    elif args.command == "import-job":
        if root.exists() and any(root.iterdir()): raise ValueError("Import into an empty workspace to preserve existing files")
        with tempfile.TemporaryDirectory(prefix="moom-import-") as temporary:
            staged = Path(temporary)
            with zipfile.ZipFile(args.archive) as archive:
                for item in archive.infolist():
                    if item.is_dir(): continue
                    if item.filename.startswith(("/", "\\")) or "\\" in item.filename: raise ValueError("Invalid import path")
                    target = within(staged, item.filename)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(archive.read(item))
            read(staged / "docs/workspace.json")
            shutil.copytree(staged, root, dirs_exist_ok=True)
        config = workspace(root); config.pop("approved_workflow", None); config["import_review"] = "required"
        write(root / "docs/workspace.json", config)
        result = {"imported": str(root), "review": "required"}
    else:
        config = workspace(root)
        if args.command == "switch":
            state = project(root, config, args.project)
            config["active_project"] = state["id"]
            write(root / "docs/workspace.json", config)
            result = {"active_project": state["id"]}
        elif args.command == "status":
            if args.json:
                print(json.dumps({"workspace": config, "project": project(root, config) if config.get("active_project") else None}, ensure_ascii=False, indent=2)); return
            print(render(root)); return
        elif args.command in ("procedure", "run"):
            state = project(root, config)
            flow, folder = recipe(root, config, state)
            if args.command == "procedure":
                selected = next(s for s in flow["steps"] if s["id"] == args.step)
                path = within(folder, selected["procedure"])
                print(f"Project: {state['id']} · workflow {flow['revision']}\nProcedure: {path}\n\n{path.read_text(encoding='utf-8')}"); return
            helper = flow["helpers"][args.helper]
            path = within(folder if helper.get("bundled") else root, helper["path"])
            if helper.get("sha256") and digest(path) != helper["sha256"]: raise ValueError("Pinned helper changed; record a workflow revision")
            bundle_root = folder / "bundle" if flow.get("resources_bundled") else root
            for name, expected in flow.get("resource_sha256", {}).items():
                if digest(within(bundle_root, name)) != expected: raise ValueError("Pinned helper resource changed; record a workflow revision")
            substitutions = {"{helper}": str(path), "{project}": state["id"]}
            command = [substitutions.get(part, part) for part in helper["command"]]
            subprocess.run(command, cwd=root, env={**os.environ, "MOOM_WORKSPACE": str(root), "MOOM_PROJECT": state["id"], "MOOM_BUNDLE": str(bundle_root)}, check=True); return
        elif args.command == "iterate":
            state = project(root, config)
            result = iterate_project(root, config, state, args)
        elif args.command == "review-round":
            result = review_round(root, config, project(root, config), args)
        elif args.command == "versions":
            state = project(root, config)
            result = {"project": state["id"], "working": state["version"], "docs": str(project_docs(root, state)), "roadmap": f"projects/{state['id']}/roadmap.md", "history": state.get("releases", [])}
        elif args.command == "check":
            changed = []
            for identifier in config["projects"]:
                state = project(root, config, identifier)
                metadata = read(root / "projects" / state["id"] / "project.json")
                version_record = read(project_docs(root, state) / "version.json") if state.get("docs") else {"version": state["version"]}
                if metadata["version"] != state["version"] or version_record["version"] != state["version"]:
                    raise ValueError("Project/version records disagree; use iterate with the primary version input instead of relabelling files")
                entry = version_record.get("change_input")
                if entry:
                    primary = within(project_docs(root, state), entry["file"])
                    if entry["entry_mode"] not in ("agent-assisted", "owner-prepared") or not primary.is_file() or digest(primary) != entry["sha256"]:
                        raise ValueError("Primary version input changed or is invalid; reread and record its actual revision before proceeding")
                flow, folder = recipe(root, config, state)
                validate_recipe(root, flow, folder)
                affected = set()
                for identifier, item in state["milestones"].items():
                    if not within(root, item["artifact"]).exists() or digest(within(root, item["artifact"])) != item["sha256"]:
                        item["state"] = "stale"; changed.append(f"{state['id']}:{identifier}")
                        affected.add(identifier)
                for step in flow["steps"]:
                    if affected.intersection(step.get("depends_on", [])):
                        affected.add(step["id"])
                        if step["id"] in state["milestones"]:
                            state["milestones"][step["id"]]["state"] = "stale"
                save_project(root, config, state)
            result = {"stale_artifacts": changed, "integration": sync(root, True)}
    render(root)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, OSError, StopIteration) as error:
        print(f"Moom: {error}", file=sys.stderr)
        sys.exit(2)
