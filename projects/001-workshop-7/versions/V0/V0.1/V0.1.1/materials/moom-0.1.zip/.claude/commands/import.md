---
description: "Moom import: Import someone else's reusable method. Use for this workspace's import procedure."
---

<!-- moom:generated; edit docs/commands or the job procedure, then sync -->
Read AGENTS.md and docs/process.md. Read current project state with python3 moom.py status --json.
Read docs/commands/import.md in full and follow it.
Use plain-language requests equivalently; existing authorization and latest user instructions apply.
