---
name: export
description: "Moom export: Export a reusable job kit. Use for this workspace's export procedure."
---

<!-- moom:generated; edit docs/commands or the job procedure, then sync -->
Read AGENTS.md and docs/process.md. Read current project state with python3 moom.py status --json.
Read docs/commands/export.md in full and follow it.
Use plain-language requests equivalently; existing authorization and latest user instructions apply.
