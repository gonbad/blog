# Workspace roadmap

## Start

Discover the real job from its first project. Put shared method/tool improvements here; put each result's scope and future versions in projects/ID/roadmap.md.

## Available mechanics

- Numbered review rounds within each project's versioned documents; options with one recommendation are separate from confirm/override decisions.
- Project version documents, previous-source snapshots, project roadmaps, and a distinct frozen workflow revision.

## Candidate improvements

Record improvements discovered during actual work. A roadmap item is not authorization to implement or publish it. Native host discovery and real external execution require their own evidence.
