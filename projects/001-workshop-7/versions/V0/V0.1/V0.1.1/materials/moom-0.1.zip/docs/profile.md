# Workspace profile

Conversation language: not collected yet.
Document language: not collected yet.
Selected assistant/tool: not collected yet.

During /start, ask for the language pair first, then only missing universal setup information. A server, renderer, API or domain is a job/project dependency, not universal setup. Record actual Git/remote evidence without putting credentials here.
