---
name: job
description: "Moom job: Discover the repeated job through Project 001. Use for this workspace's job procedure."
---

<!-- moom:generated; edit docs/commands or the job procedure, then sync -->
Read AGENTS.md and docs/process.md. Read current project state with python3 moom.py status --json.
Read docs/commands/job.md in full and follow it.
Use plain-language requests equivalently; existing authorization and latest user instructions apply.
