---
name: start
description: "Moom start: Start the Moom workspace. Use for this workspace's start procedure."
---

<!-- moom:generated; edit docs/commands or the job procedure, then sync -->
Read AGENTS.md and docs/process.md. Read current project state with python3 moom.py status --json.
Read docs/commands/start.md in full and follow it.
Use plain-language requests equivalently; existing authorization and latest user instructions apply.
