# Workspace status

Moom kit: 0.1
Projects: 0
Active project: none
Next: /start, then /job with the first real example.

Generated from workspace/project state. Approval is recorded separately from artifact readiness.
