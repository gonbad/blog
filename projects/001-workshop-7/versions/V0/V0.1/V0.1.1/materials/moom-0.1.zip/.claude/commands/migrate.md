---
description: "Moom migrate: Apply a selected workflow revision to an existing project. Use for this workspace's migrate procedure."
---

<!-- moom:generated; edit docs/commands or the job procedure, then sync -->
Read AGENTS.md and docs/process.md. Read current project state with python3 moom.py status --json.
Read docs/commands/migrate.md in full and follow it.
Use plain-language requests equivalently; existing authorization and latest user instructions apply.
