---
name: status
description: "Moom status: Show project progress and resume. Use for this workspace's status procedure."
---

<!-- moom:generated; edit docs/commands or the job procedure, then sync -->
Read AGENTS.md and docs/process.md. Read current project state with python3 moom.py status --json.
Read docs/commands/status.md in full and follow it.
Use plain-language requests equivalently; existing authorization and latest user instructions apply.
