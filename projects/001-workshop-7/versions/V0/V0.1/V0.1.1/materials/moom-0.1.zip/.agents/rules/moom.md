Read AGENTS.md and docs/status.md. Procedures live in docs/commands. Job steps resolve through python3 moom.py procedure STEP for the selected project's workflow revision.
