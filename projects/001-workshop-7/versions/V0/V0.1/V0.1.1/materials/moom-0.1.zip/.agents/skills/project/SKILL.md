---
name: project
description: "Moom project: Start another instance of the current job. Use for this workspace's project procedure."
---

<!-- moom:generated; edit docs/commands or the job procedure, then sync -->
Read AGENTS.md and docs/process.md. Read current project state with python3 moom.py status --json.
Read docs/commands/project.md in full and follow it.
Use plain-language requests equivalently; existing authorization and latest user instructions apply.
