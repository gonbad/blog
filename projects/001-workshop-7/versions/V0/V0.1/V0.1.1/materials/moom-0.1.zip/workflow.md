# Moom workflow

These are real procedures under [docs/commands/](docs/commands/), backed by [moom.py](moom.py). Invoke them through generated host commands or equivalent ordinary language.

Each project has versioned documents and roadmap.md. Each review round has a new numbered file; Questions have options with one recommendation, while Uncertain decisions have Confirmation / override fields. Before implementing each new result, put the proposed result, unresolved questions, uncertain decisions and overrides in docs/projects/ID/versions/VVERSION/NNN-review.md with empty Answer fields. Link the file and wait for saved answers; do not ask project questions in chat or question tools. Preserve the answers and record decisions separately. The assistant owns research; missing owner inputs specify the required stage, destination and blocking scope. The complete protocol is in [docs/process.md](docs/process.md).

```mermaid
flowchart TD
  start["/start: missing universal setup"] --> job["/job: first real input + Project 001"]
  job --> questions["NNN-review.md: proposals, uncertainties, owner inputs"]
  questions --> wait["Wait for saved answers; preserve confirmed decisions"]
  wait --> sample["Make and review a representative result"]
  sample --> method["Extract and freeze the specialized method"]
  method --> stages["Selected project's actual job milestones"]
  stages --> project["/project: another input, same method"]
  project --> questions
  stages --> issue["/issue: correct result/helper/method/core"]
  issue --> stages
  issue --> change["/workflow: scoped method improvement"]
  change --> migrate["/migrate: reopen only affected current work"]
  migrate --> stages
```

| Request | Canonical procedure | Mechanical support |
|---|---|---|
| Start | [start](docs/commands/start.md) | Existing profile, Git, `status`, `sync` |
| First job | [job](docs/commands/job.md) | Idempotent `new --first`, `freeze`, `migrate` |
| Another instance | [project](docs/commands/project.md) | `new`, actual projects/ID/source |
| Return to previous work | [switch](docs/commands/switch.md) | `switch`, fresh-process state restoration |
| Correct a result | [issue](docs/commands/issue.md) | Project-scoped issue ledger and checks |
| Add a feature | [iterate](docs/commands/iterate.md) | Version record and selected project's workflow |
| Change the method | [workflow](docs/commands/workflow.md), [migrate](docs/commands/migrate.md) | Frozen procedures, helper code/resources, affected-stage invalidation |
| Share/reuse | [export](docs/commands/export.md), [import](docs/commands/import.md) | Standalone ZIP, clean recipient profile, review required |

The inner workflow is discovered from the task and recorded in `docs/job/workflow.json`. Each project records the revision it uses. `python3 moom.py procedure STEP` resolves its actual instructions; `run HELPER` runs its selected code with its declared resources. Readiness and human acceptance remain separate. No timing benchmark is required.

New versions have two entry routes: /iterate or /workflow creates a version folder with 01-request.md from an authorized change/roadmap idea; alternatively, the owner creates that folder and a primary 01-*.md file and the assistant adopts it with --input. Both preserve source history and owner input. Read that primary input before inherited specifications and check source-to-result fidelity separately from appearance/functionality.
