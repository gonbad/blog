# Repeated task

Discover this from the owner's real task and Project 001. Record inputs, outputs, quality criteria, recurring decisions and boundaries. Do not invent a task from the kit's examples.
