# blog-publisher

Create independently designed articles, guides, papers or presentations with verified offline packages and optional shared hosting.

Job revision: 0.4

This is an adaptable initial base. Change any step, format or style to fit the
participant’s exact work, including while doing a real Project. No fixed schema,
orientation, toolkit or bundled runtime limits the result. Start with the real idea.

## Suggested ordered full pipeline

| Step | Persian label | Command | Condition |
| --- | --- | --- | --- |
| Idea and scope | ایده و دامنه | [job-idea](commands/job-idea.md) | Adapt to actual needs |
| Editorial brief | بریف و زاویه دید | [job-brief](commands/job-brief.md) | Adapt to actual needs |
| Story structure | ساختار روایت و رئوس | [job-story](commands/job-story.md) | Adapt to actual needs |
| Content authoring | نگارش متن و محتوا | [job-content](commands/job-content.md) | Adapt to actual needs |
| Layout and styling | صفحه‌آرایی و گرافیک | [job-layout](commands/job-layout.md) | Adapt to actual needs |
| Build and package | ساخت و بسته‌بندی پکیج | [job-build](commands/job-build.md) | Adapt to actual needs |
| Publish or deliver | انتشار یا تحویل | [job-deploy](commands/job-deploy.md) | Local delivery may skip hosting |

For version 0.1 follow the chosen full pipeline. Later versions use only affected
steps and prerequisites, recording skipped steps and reasons. Every command resolves
workspace-root paths, applies file review/certainty, checks the four mutable domains
and ends with dynamic localized progress plus one exact next action.

## References to install and read when relevant

- [workflow](references/workflow.md): Read for state, review and every step handoff.
- [distribution](references/distribution.md): Read for public builds, packaging and publishing.
- [infrastructure](references/infrastructure.md): Read when connecting services or deploying.
- [quality](references/quality.md): Read when defining acceptance, testing and delivering.

## Retained workshop work

The pipeline preserves the unmerged editorial stages: idea and scope in idea;
thesis and angle in brief; narrative progression and section hierarchy in story;
full prose and code listings in content; typography and visual diagrams in layout;
static compilation, link validation and offline packaging in build; and journal
release propagation in deploy.
